import { useState, useEffect } from 'react'
import { ethers } from 'ethers'
import detectEthereumProvider from '@metamask/detect-provider'

// Time-Locked Wallet Contract ABI
const TIME_LOCKED_WALLET_ABI = [
  {
    "inputs": [{"internalType": "uint256", "name": "_unlockTimestamp", "type": "uint256"}],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "anonymous": false,
    "inputs": [
      {"indexed": true, "internalType": "address", "name": "account", "type": "address"}
    ],
    "name": "AddressWhitelisted",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {"indexed": true, "internalType": "address", "name": "sender", "type": "address"},
      {"indexed": false, "internalType": "uint256", "name": "amount", "type": "uint256"},
      {"indexed": false, "internalType": "uint256", "name": "timestamp", "type": "uint256"}
    ],
    "name": "FundsDeposited",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {"indexed": true, "internalType": "address", "name": "recipient", "type": "address"},
      {"indexed": false, "internalType": "uint256", "name": "amount", "type": "uint256"},
      {"indexed": false, "internalType": "uint256", "name": "timestamp", "type": "uint256"}
    ],
    "name": "FundsWithdrawn",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {"indexed": false, "internalType": "uint256", "name": "oldTimestamp", "type": "uint256"},
      {"indexed": false, "internalType": "uint256", "name": "newTimestamp", "type": "uint256"}
    ],
    "name": "UnlockTimeExtended",
    "type": "event"
  },
  {
    "inputs": [{"internalType": "address", "name": "_account", "type": "address"}],
    "name": "addToWhitelist",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [{"internalType": "uint256", "name": "_newUnlockTimestamp", "type": "uint256"}],
    "name": "extendUnlockTime",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "owner",
    "outputs": [{"internalType": "address", "name": "", "type": "address"}],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "unlockTimestamp",
    "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [{"internalType": "address", "name": "", "type": "address"}],
    "name": "whitelistedAddresses",
    "outputs": [{"internalType": "bool", "name": "", "type": "bool"}],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "withdraw",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "stateMutability": "payable",
    "type": "receive"
  }
]

export const useWeb3 = () => {
  const [provider, setProvider] = useState(null)
  const [signer, setSigner] = useState(null)
  const [account, setAccount] = useState('')
  const [isConnected, setIsConnected] = useState(false)
  const [contract, setContract] = useState(null)
  const [contractAddress, setContractAddress] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  // Initialize Web3 provider
  const initializeProvider = async () => {
    try {
      const ethereumProvider = await detectEthereumProvider()
      
      if (ethereumProvider) {
        const web3Provider = new ethers.BrowserProvider(ethereumProvider)
        setProvider(web3Provider)
        
        // Check if already connected
        const accounts = await ethereumProvider.request({ method: 'eth_accounts' })
        if (accounts.length > 0) {
          setAccount(accounts[0])
          setIsConnected(true)
          const web3Signer = await web3Provider.getSigner()
          setSigner(web3Signer)
        }
      } else {
        setError('Please install MetaMask!')
      }
    } catch (err) {
      setError('Failed to initialize Web3 provider')
      console.error(err)
    }
  }

  // Connect wallet
  const connectWallet = async () => {
    try {
      setLoading(true)
      setError('')
      
      if (!provider) {
        await initializeProvider()
      }
      
      const accounts = await window.ethereum.request({
        method: 'eth_requestAccounts'
      })
      
      if (accounts.length > 0) {
        setAccount(accounts[0])
        setIsConnected(true)
        const web3Signer = await provider.getSigner()
        setSigner(web3Signer)
      }
    } catch (err) {
      setError('Failed to connect wallet')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  // Disconnect wallet
  const disconnectWallet = () => {
    setAccount('')
    setIsConnected(false)
    setSigner(null)
    setContract(null)
    setContractAddress('')
  }

  // Deploy contract
  const deployContract = async (unlockTimestamp) => {
    try {
      setLoading(true)
      setError('')
      
      if (!signer) {
        throw new Error('Wallet not connected')
      }

      // For demo purposes, we'll simulate contract deployment
      // In a real scenario, you would deploy the actual contract
      const mockContractAddress = '0x' + Math.random().toString(16).substr(2, 40)
      setContractAddress(mockContractAddress)
      
      // Create contract instance (mock)
      const contractInstance = new ethers.Contract(
        mockContractAddress,
        TIME_LOCKED_WALLET_ABI,
        signer
      )
      setContract(contractInstance)
      
      return mockContractAddress
    } catch (err) {
      setError('Failed to deploy contract')
      console.error(err)
      throw err
    } finally {
      setLoading(false)
    }
  }

  // Connect to existing contract
  const connectToContract = async (address) => {
    try {
      setLoading(true)
      setError('')
      
      if (!signer) {
        throw new Error('Wallet not connected')
      }

      const contractInstance = new ethers.Contract(
        address,
        TIME_LOCKED_WALLET_ABI,
        signer
      )
      
      setContract(contractInstance)
      setContractAddress(address)
    } catch (err) {
      setError('Failed to connect to contract')
      console.error(err)
      throw err
    } finally {
      setLoading(false)
    }
  }

  // Deposit funds
  const depositFunds = async (amount) => {
    try {
      setLoading(true)
      setError('')
      
      if (!contract) {
        throw new Error('Contract not connected')
      }

      // For demo purposes, simulate transaction
      const amountWei = ethers.parseEther(amount.toString())
      
      // Mock transaction
      console.log(`Depositing ${amount} ETH to contract ${contractAddress}`)
      
      // In real implementation:
      // const tx = await signer.sendTransaction({
      //   to: contractAddress,
      //   value: amountWei
      // })
      // await tx.wait()
      
      return { hash: '0x' + Math.random().toString(16).substr(2, 64) }
    } catch (err) {
      setError('Failed to deposit funds')
      console.error(err)
      throw err
    } finally {
      setLoading(false)
    }
  }

  // Withdraw funds
  const withdrawFunds = async () => {
    try {
      setLoading(true)
      setError('')
      
      if (!contract) {
        throw new Error('Contract not connected')
      }

      // Mock transaction
      console.log('Withdrawing funds from contract')
      
      // In real implementation:
      // const tx = await contract.withdraw()
      // await tx.wait()
      
      return { hash: '0x' + Math.random().toString(16).substr(2, 64) }
    } catch (err) {
      setError('Failed to withdraw funds')
      console.error(err)
      throw err
    } finally {
      setLoading(false)
    }
  }

  // Extend unlock time
  const extendUnlockTime = async (newTimestamp) => {
    try {
      setLoading(true)
      setError('')
      
      if (!contract) {
        throw new Error('Contract not connected')
      }

      // Mock transaction
      console.log(`Extending unlock time to ${newTimestamp}`)
      
      // In real implementation:
      // const tx = await contract.extendUnlockTime(newTimestamp)
      // await tx.wait()
      
      return { hash: '0x' + Math.random().toString(16).substr(2, 64) }
    } catch (err) {
      setError('Failed to extend unlock time')
      console.error(err)
      throw err
    } finally {
      setLoading(false)
    }
  }

  // Add to whitelist
  const addToWhitelist = async (address) => {
    try {
      setLoading(true)
      setError('')
      
      if (!contract) {
        throw new Error('Contract not connected')
      }

      // Mock transaction
      console.log(`Adding ${address} to whitelist`)
      
      // In real implementation:
      // const tx = await contract.addToWhitelist(address)
      // await tx.wait()
      
      return { hash: '0x' + Math.random().toString(16).substr(2, 64) }
    } catch (err) {
      setError('Failed to add to whitelist')
      console.error(err)
      throw err
    } finally {
      setLoading(false)
    }
  }

  // Get contract balance
  const getContractBalance = async () => {
    try {
      if (!provider || !contractAddress) {
        return '0'
      }

      // Mock balance
      return '2.5'
      
      // In real implementation:
      // const balance = await provider.getBalance(contractAddress)
      // return ethers.formatEther(balance)
    } catch (err) {
      console.error('Failed to get contract balance:', err)
      return '0'
    }
  }

  // Get unlock timestamp
  const getUnlockTimestamp = async () => {
    try {
      if (!contract) {
        return null
      }

      // Mock timestamp (24 hours from now)
      return Math.floor(Date.now() / 1000) + (24 * 60 * 60)
      
      // In real implementation:
      // const timestamp = await contract.unlockTimestamp()
      // return timestamp.toString()
    } catch (err) {
      console.error('Failed to get unlock timestamp:', err)
      return null
    }
  }

  // Check if address is whitelisted
  const isWhitelisted = async (address) => {
    try {
      if (!contract) {
        return false
      }

      // Mock whitelist check
      const mockWhitelist = [
        '0x742d35Cc6634C0532925a3b8D4C9db96590c6C87',
        '0x8ba1f109551bD432803012645Hac136c'
      ]
      return mockWhitelist.includes(address)
      
      // In real implementation:
      // return await contract.whitelistedAddresses(address)
    } catch (err) {
      console.error('Failed to check whitelist status:', err)
      return false
    }
  }

  useEffect(() => {
    initializeProvider()
  }, [])

  return {
    provider,
    signer,
    account,
    isConnected,
    contract,
    contractAddress,
    loading,
    error,
    connectWallet,
    disconnectWallet,
    deployContract,
    connectToContract,
    depositFunds,
    withdrawFunds,
    extendUnlockTime,
    addToWhitelist,
    getContractBalance,
    getUnlockTimestamp,
    isWhitelisted
  }
}

