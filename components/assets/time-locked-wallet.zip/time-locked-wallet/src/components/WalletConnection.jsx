import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Wallet, CheckCircle, AlertCircle, Loader2 } from 'lucide-react'

export const WalletConnection = ({ 
  isConnected, 
  account, 
  loading, 
  error, 
  onConnect, 
  onDisconnect 
}) => {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="mb-8"
    >
      <Card className="bg-white/10 backdrop-blur-lg border-white/20">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Wallet className="w-6 h-6 text-purple-400" />
              <div>
                <span className="text-white font-medium block">
                  {isConnected ? `Connected: ${account.slice(0, 6)}...${account.slice(-4)}` : 'Not Connected'}
                </span>
                {error && (
                  <span className="text-red-400 text-sm flex items-center mt-1">
                    <AlertCircle className="w-4 h-4 mr-1" />
                    {error}
                  </span>
                )}
              </div>
            </div>
            
            {!isConnected ? (
              <Button 
                onClick={onConnect}
                disabled={loading}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 transform hover:scale-105 transition-all duration-200"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Connecting...
                  </>
                ) : (
                  'Connect Wallet'
                )}
              </Button>
            ) : (
              <div className="flex items-center space-x-3">
                <Badge variant="secondary" className="bg-green-500/20 text-green-400 border-green-500/30">
                  <CheckCircle className="w-4 h-4 mr-1" />
                  Connected
                </Badge>
                <Button 
                  variant="outline"
                  onClick={onDisconnect}
                  className="border-red-500/50 text-red-400 hover:bg-red-500/20"
                >
                  Disconnect
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}

